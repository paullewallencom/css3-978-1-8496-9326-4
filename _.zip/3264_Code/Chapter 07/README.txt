=== Video Killed the Radio Star ===

A web console entirely created using CSS that applies
masking effects and filters to a running video.

To run the code simply point a web browser to index.html.
