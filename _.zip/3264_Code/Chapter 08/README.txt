=== Go Go Gauges ===

A small HTML widget configurable using data-* attributes

To run the code simply point a web browser to index.html.