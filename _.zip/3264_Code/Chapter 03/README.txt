== Omnimenu ==

A two-levels menu that uses media query to works both
on smartphones and desktop.

To run the code simply point a web browser to index.html.
