== ZUI ==

A small interface to zoom in and out an SVG infographic 
using CSS3 transform and transition properties

To run the code simply point a web browser to index.html.
