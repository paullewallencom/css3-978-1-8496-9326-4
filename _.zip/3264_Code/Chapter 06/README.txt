== Parallax ==

A single page website where the pictures scroll at different 
speed creating a nice parallax effect. 

To run the code simply point a web browser to index.html.
