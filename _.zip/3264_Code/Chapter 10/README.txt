=== Charts ===

A bar chart that supports multiple data series created using the 
new flexible box layout. 

To run the code simply point a web browser to index.html.