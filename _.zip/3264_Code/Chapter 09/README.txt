=== An intro ===

An animated sequence where a camera moves in a 3D space.

To run the code simply point a web browser to index.html.