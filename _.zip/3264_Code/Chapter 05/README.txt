== 3D Gallery ==

A pure CSS3 slideshow with multiple effects and multiple 
navigation modes built using the target pseudo-selector and
CSS transform property 

To run the code simply point a web browser to index.html.
